<body id="page-top">

     <!-- HEADER -->
     @include('header')

  <div id="wrapper">

    <!-- Sidebar -->

     @include('sidebar')

    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Add Employee</li>
        </ol>

        <!-- Page Content -->
        <p>Employee ID : {{ $results->employee_id }}</p>
        <p>Date : {{ $results->date }}</p>
        <p>Report to office at : {{ $results->Report_to_office_at }}</p>
        <p>Customer Name : {{ $results->Customer_Name }}</p>
        <p>location : {{ $results->location }}</p>
        <p>Contact Person : {{ $results->Contact_Person }}</p>
        <p>Purpose of visit : {{ $results->Purpose_of_visit }}</p>
        <p>SWO or Call reference ID : {{ $results->SWO_or_Call_reference_ID }}</p>
        <p>Date of Work : {{ $results->Date_of_Work }}</p>
        <p>Work start time : {{ $results->Work_start_time }}</p>
        <p>Work end time : {{ $results->Work_end_time }}</p>
        <p>Time Spent at Customer location : {{ $results->Time_Spent_at_Customer_location }}</p> <br>
        <p>Report to office : {{ $results->Report_to_office }}</p> <br>
        <p>Additional Remark : {{ $results->Additional_Remark }}</p> <br>
        <p>Customer response/remarks : {{ $results->Customer_response_remarks }}</p> <br>
        <p>Total Expense : {{ $results->Total_Expense }}</p> <br>
        <p>From : {{ $results->From }}</p> <br>
        <p>To : {{ $results->To }}</p> <br>
        <p>Media : {{ $results->Media }}</p> <br>
        <p>Travelling Expense : {{ $results->Travelling_Expense }}</p> <br>
        <p>Particle Extra : {{ $results->Particle_Extra }}</p> <br>
        <p>Expense : {{ $results->Expense }}</p> <br>
        <p>With : {{ $results->With }}</p> <br>
      </div>
      @include('footer')
    </div>
  </div>
</body>
