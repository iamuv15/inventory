<body id="page-top">

     <!-- HEADER -->
     @include('header')

  <div id="wrapper">

    <!-- Sidebar -->

     @include('sidebar')

    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Add Employee</li>
        </ol>

        <!-- Page Content -->
        @foreach($results as $result)
        <p>First Name : {{ $result->fname }}</p>
        <p>Last Name : {{ $result->lname }}</p>
        <p>E-mail : {{ $result->email }}</p>
        <p>Address Line 1 : {{ $result->addr1 }}</p>
        <p>Address Line 2 : {{ $result->addr2 }}</p>
        <p>City : {{ $result->city }}</p>
        <p>State : {{ $result->state }}</p>
        <p>Zip : {{ $result->zip }}</p>
        <p>Contact Number : {{ $result->contact_no }}</p>
        <p>Date of Birth : {{ $result->dob }}</p>
        <p>Document Attached : </p> <br>
        <img src="../images/{{ $result->file }}" alt="" height="400px" width="400px">
        @endforeach
      </div>
      @include('footer')
    </div>
  </div>
</body>
