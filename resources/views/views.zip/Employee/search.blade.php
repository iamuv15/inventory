<body id="page-top">

     <!-- HEADER -->
     @include('header')

  <div id="wrapper">

    <!-- Sidebar -->

     @include('sidebar')

    <div id="content-wrapper">
      <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Dashboard</a>
          </li>
          <li class="breadcrumb-item active">Add Employee</li>
        </ol>

        <!-- Page Content -->
        <form class="searchEmployee" action="{{ asset('search/employee') }}" method="post" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="employee_id">Employee ID</label>
              <input type="number" name="employee_id" class="form-control" id="employee_id" placeholder="Employee ID">
            </div>
            <input type="hidden" name="_token" value="{{ Session::token() }}">
            <div class="form-group col-md-6">
              <input type="submit" name="submit" class="btn btn-primary" value="Search...">
            </div>
          </div>
        </form>
      </div>
      @include('footer')
    </div>
  </div>
</body>
